<?php
/**
 * Recipe Index Sidebar
 */
?>

<div id="sidebar" class="site-sidebar">

    <?php dynamic_sidebar('sidebar-index'); ?>

</div>
